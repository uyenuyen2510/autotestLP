import os
import argparse
import subprocess
import datetime

PROJECTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'projects')
REPORTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'reports')

os.makedirs(REPORTS_DIR, exist_ok=True)

def list_projects():
    return [d for d in os.listdir(PROJECTS_DIR) if os.path.isdir(os.path.join(PROJECTS_DIR, d))]

def run_project(project, html_report=True):
    project_path = os.path.join(PROJECTS_DIR, project)
    # Format date as YYYYMMDD
    current_date = datetime.datetime.now().strftime('%Y%m%d')
    report_path = os.path.join(REPORTS_DIR, f'{current_date}_{project}_report.html')
    cmd = [
        'pytest', project_path,
        '--maxfail=1',
        '--disable-warnings'
    ]
    if html_report:
        cmd += ['--html', report_path, '--self-contained-html']
    env = os.environ.copy()
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    env['PYTHONPATH'] = root_dir + os.pathsep + env.get('PYTHONPATH', '')
    subprocess.run(cmd, env=env)

def run_all_projects(html_report=True):
    for project in list_projects():
        run_project(project, html_report)

def clear_reports_and_screenshots():
    import shutil
    for folder in [REPORTS_DIR, os.path.join(os.path.dirname(__file__), '..', 'screenshots')]:
        if os.path.exists(folder):
            for filename in os.listdir(folder):
                file_path = os.path.join(folder, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f'Không thể xóa {file_path}: {e}')
    print('Đã xoá sạch reports và screenshots!')

def main():
    parser = argparse.ArgumentParser(description='Test Framework Runner')
    parser.add_argument('--project', type=str, help='Project to run (default: all)')
    parser.add_argument('--no-html', action='store_true', help='Disable HTML report')
    parser.add_argument('--clear', action='store_true', help='Clear reports and screenshots')
    args = parser.parse_args()
    if args.clear:
        clear_reports_and_screenshots()
        return
    if args.project:
        run_project(args.project, not args.no_html)
    else:
        run_all_projects(not args.no_html)

if __name__ == '__main__':
    main()
