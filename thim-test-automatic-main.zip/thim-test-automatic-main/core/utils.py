from bs4 import BeautifulSoup
import requests

def fetch_html(url):
    resp = requests.get(url)
    resp.raise_for_status()
    return resp.text

def parse_html(html):
    return BeautifulSoup(html, 'html.parser')
