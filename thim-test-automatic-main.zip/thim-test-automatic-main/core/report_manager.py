import os
import datetime

def get_report_filename(project):
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    return f'{project}_report_{timestamp}.html'
