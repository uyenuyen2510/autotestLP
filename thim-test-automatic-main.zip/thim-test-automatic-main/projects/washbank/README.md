# Washbank Kiosk Selenium Test Project

Thư mục này chứa các test case tự động cho kiosk Washbank sử dụng Selenium và pytest.

## Cấu trúc thư mục

- `test_washbank_kiosk.py`: Các test case chính cho chức năng kiosk Washbank.
- `__init__.py`: Để Python nhận diện đây là một package.
- `README.md`: Hướng dẫn sử dụng và cấu trúc project.

## Cách chạy test

```bash
pytest test_washbank_kiosk.py -v -s
```

## Yêu cầu
- Python 3.7+
- selenium
- webdriver-manager
- pytest

Cài đặt dependencies:
```bash
pip install selenium webdriver-manager pytest
```

## Ghi chú
- Để đóng trình duyệt sau khi test, bỏ comment dòng `cls.driver.quit()` trong `teardown_class`.
- Có thể thêm các test case mới vào file hoặc tách ra file khác nếu cần.
