import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

class TestWashbankKiosk:
    @classmethod
    def setup_class(cls):
        """Chạy một lần trước tất cả các test"""
        cls.service = Service(ChromeDriverManager().install())
        cls.driver = webdriver.Chrome(service=cls.service)
        cls.driver.implicitly_wait(10)
        
    def setup_method(self):
        """Chạy trước mỗi test case"""
        self.driver.get("https://admin.washbank.co.kr/kiosk/login/")
        self.login()
    
    def teardown_class(cls):
        """Chạy một lần sau tất cả các test"""
        # Bỏ comment dòng dưới nếu muốn đóng trình duyệt sau khi chạy xong
        # cls.driver.quit()
        pass

    def login(self):
        """Hàm đăng nhập"""
        try:
            # Nhập username
            username_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.NAME, "username"))
            )
            username_input.clear()
            username_input.send_keys("s001admin")

            # Nhập password
            password_input = self.driver.find_element(By.NAME, "password")
            password_input.clear()
            password_input.send_keys("ss1adm")

            # Click nút đăng nhập
            submit_btn = self.driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
            submit_btn.click()

            # Chờ đăng nhập thành công
            WebDriverWait(self.driver, 20).until(
                lambda driver: "/kiosk/" in driver.current_url and "login" not in driver.current_url
            )
            print(f"Đăng nhập thành công! URL hiện tại: {self.driver.current_url}")
            
        except Exception as e:
            print(f"Lỗi khi đăng nhập: {str(e)}")
            raise

    def test_check_dashboard(self):
        """Kiểm tra trang dashboard sau khi đăng nhập: chỉ cần thấy link nhập số điện thoại là thành công"""
        try:
            # Kiểm tra sự xuất hiện của thẻ <a href='/kiosk/phone-number/'> (sau khi đăng nhập)
            phone_link = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "a[href='/kiosk/phone-number/']"))
            )
            print("✅ Đã tìm thấy chỗ nhập phone number, test đăng nhập kiosk thành công!")
        except Exception as e:
            print(f"❌ Không tìm thấy link nhập số điện thoại sau đăng nhập: {str(e)}")
            raise


# Để chạy test, sử dụng lệnh:
# pytest test_washbank_kiosk.py -v -s --pdb
# Tùy chọn --pdb sẽ dừng ở điểm lỗi để debug
