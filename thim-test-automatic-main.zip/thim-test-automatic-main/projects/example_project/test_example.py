import unittest
from core.base_test import BaseTest
from selenium.webdriver.common.by import By

class ExampleUITest(BaseTest):
    def test_google_title(self):
        self.driver.get('https://www.google.com')
        self.assertIn('Google', self.driver.title)

if __name__ == '__main__':
    unittest.main()
