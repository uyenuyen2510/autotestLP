# Hướng dẫn cài đặt Test Framework

## Yêu cầu chung
- Python >= 3.8
- Git (nên có)
- Internet để tải dependencies

## 1. Cài đặt trên Ubuntu/Linux
```bash
# Cài Python và pip nếu chưa có
sudo apt update
sudo apt install python3 python3-pip python3-venv git -y

# Clone source code
# git clone <repo-url> && cd <repo-folder>

# Tạo môi trường ảo và cài dependencies
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 2. Cài đặt trên Windows
```bat
REM Cài Python từ https://python.org/downloads (chọn Add to PATH khi cài)
REM Cài git nếu cần: https://git-scm.com/download/win

REM Clone source code
REM git clone <repo-url> && cd <repo-folder>

REM Tạo môi trường ảo và cài dependencies
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Cài đặt trên MacOS
```bash
# Cài Homebrew nếu chưa có: https://brew.sh/
brew install python git

# Clone source code
# git clone <repo-url> && cd <repo-folder>

# Tạo môi trường ảo và cài dependencies
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 4. Lưu ý
- Luôn kích hoạt môi trường ảo trước khi chạy test: `source venv/bin/activate` (Linux/Mac) hoặc `venv\Scripts\activate` (Windows)
- Nếu gặp lỗi driver selenium, hãy đảm bảo máy có Chrome/Chromium/Edge tương ứng.
- Có thể chỉnh sửa `config.yaml` để đổi base_url, browser mặc định.
- Báo cáo test sẽ sinh ra ở thư mục `reports/`.

## 5. Chạy thử nghiệm
```bash
# Chạy tất cả project test
python core/runner.py

# Chạy 1 project cụ thể
python core/runner.py --project example_project

# Xoá sạch toàn bộ báo cáo và ảnh chụp màn hình
python core/runner.py --clear
```

## 6. Troubleshooting
- Nếu gặp lỗi import, kiểm tra lại PYTHONPATH hoặc cài đặt đúng môi trường ảo.
- Nếu pip lỗi, thử nâng cấp pip: `pip install --upgrade pip`
- Nếu thiếu ChromeDriver, kiểm tra lại Chrome/Chromium đã cài chưa.

## 7. Tham khảo
- [Selenium Docs](https://selenium-python.readthedocs.io/)
- [Pytest Docs](https://docs.pytest.org/en/stable/)
- [BeautifulSoup Docs](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)
