# Tài liệu hệ thống Test Automation Framework

## Giới thiệu
Đây là framework kiểm thử tự động hoá với Selenium, Pytest, Unittest, hỗ trợ quản lý nhiều project, sinh báo cáo HTML, chạy song song, kiểm thử API/web UI.

## Mục lục
- [Cài đặt trên Windows/Linux/MacOS](INSTALL.md)
- [Cấu trúc thư mục](#cau-truc-thu-muc)
- [Cách viết test mới](#cach-viet-test)
- [Chạy test và sinh báo cáo](#chay-test)
- [Tùy biến cấu hình](#tuy-bien-cau-hinh)
- [Troubleshooting](#troubleshooting)

## Cấu trúc thư mục
```
core/           # Code framework chung (base, runner, utils, ...)
projects/       # Chứa các project test riêng biệt
reports/        # Báo cáo test HTML
config.yaml     # Cấu hình chung
requirements.txt
```

## Cách viết test mới
- Mỗi project nằm trong projects/<project_name>/
- Test UI kế thừa core/base_test.py (Selenium + Unittest):
```python
from core.base_test import BaseTest
class MyTest(BaseTest):
    def test_title(self):
        self.driver.get('https://example.com')
        self.assertIn('Example', self.driver.title)
```
- Test API dùng requests, BeautifulSoup4:
```python
import requests
from core.utils import parse_html
resp = requests.get('https://example.com')
soup = parse_html(resp.text)
assert soup.title.text == 'Example'
```

## Chạy test và sinh báo cáo
- Chạy tất cả project: `python core/runner.py`
- Chạy 1 project: `python core/runner.py --project <project_name>`
- Tắt báo cáo HTML: `python core/runner.py --no-html`
- Báo cáo sẽ lưu ở reports/<project>_report.html

## Tuỳ biến cấu hình
- Thay đổi browser, base_url trong config.yaml
- Có thể mở rộng core/ hoặc từng project riêng

## Troubleshooting
- Xem chi tiết INSTALL.md
- Kiểm tra môi trường ảo, driver, import, version Python nếu gặp lỗi

## Đóng góp
- Fork, tạo PR hoặc issue nếu muốn đóng góp/thắc mắc.
