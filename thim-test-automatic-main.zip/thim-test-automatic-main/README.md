# Python Test Automation Framework

## Công nghệ sử dụng
- Selenium, Webdriver Manager
- Pytest, pytest-html, pytest-xdist
- Requests, BeautifulSoup4
- Html-TestRunner
- Unittest

## Cấu trúc thư mục
```
core/           # Code framework chung
projects/       # Chứa các project test riêng biệt
reports/        # Báo cáo test
config.yaml     # Cấu hình chung
requirements.txt
```

## Cách sử dụng

1. Cài đặt thư viện:
```bash
pip install -r requirements.txt
```
2. Thêm project vào thư mục `projects/`.
3. Chạy tất cả project:
```bash
python core/runner.py
```
4. Chạy 1 project cụ thể:
```bash
python core/runner.py --project ten_project
```
5. Tắt báo cáo HTML:
```bash
python core/runner.py --no-html
```

## Viết test
- Kế thừa `core/base_test.py` cho test UI.
- Có thể dùng requests, BeautifulSoup4 cho test API/web.
- Báo cáo sẽ lưu trong thư mục `reports/`.
# thim-test-automatic
